package com.senai.crudjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudjavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
